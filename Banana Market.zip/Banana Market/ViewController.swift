//
//  ViewController.swift
//  Banana Market
//
//  Created by Justin C. Mullins on 4/8/18.
//  Copyright © 2018 saltywater. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var wallet: UILabel!
    @IBOutlet weak var dayNumber: UILabel!
    
    @IBOutlet weak var bananaQuantity: UILabel!
    
    @IBOutlet weak var bananaPrice: UILabel!
    

    @IBOutlet weak var sliverValueLabel: UILabel!
    
    @IBOutlet weak var sliderValue: UISlider!
    
    @IBAction func sellButtonPressed(_ sender: UIButton) {
        
        var bQ = Int (bananaQuantity.text!)
        var sVL = Int (sliverValueLabel.text!)
        var w = Int(wallet.text!)
        var bP = Int (bananaPrice.text!)
        var d = Int(dayNumber.text!)
        if (bQ! >= sVL!)
        {
            bQ = bQ! - sVL!
            w = w! + (bP! * sVL!)
            d = d! + 1
            
            
            print(String(describing: bQ!))
            print(String(describing: w!))
            print(String(describing: d!))
            bananaQuantity.text = String(describing: bQ!)
            wallet.text = String(describing: w!)
            dayNumber.text = String(describing: d!)
            bP = Int(arc4random_uniform(10) + 1)
            bananaPrice.text = String(describing: bP!)
        }
        else
        {
            //
        }
    }
    
    @IBAction func holdButtonPressed(_ sender: UIButton) {
        var d = Int(dayNumber.text!)
        d = d! + 1
        dayNumber.text = String(describing: d!)
        
        var bP = Int(arc4random_uniform(10) + 1)
        bananaPrice.text = String(describing: bP)
    }
    
    
    @IBAction func buyButtonPressed(_ sender: UIButton) {
        
        var bQ = Int (bananaQuantity.text!)
        var sVL = Int (sliverValueLabel.text!)
        var w = Int(wallet.text!)
        var bP = Int (bananaPrice.text!)
        var d = Int(dayNumber.text!)
       
        if (w! >= sVL! * bP!)
        {
            bQ = bQ! + sVL!
            w = w! - (bP! * sVL!)
            d = d! + 1
            
            bananaQuantity.text = String(describing: bQ!)
            wallet.text = String(describing: w!)
            dayNumber.text = String(describing: d!)
            bP = Int(arc4random_uniform(10) + 1)
            bananaPrice.text = String(describing: bP!)
        }
        else
        {
            //
        }
    }
    
    
    @IBAction func sliderChanged(_ sender: UISlider) {
        sliverValueLabel.text = String(Int(sliderValue.value))
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        var bP = Int(arc4random_uniform(10) + 1)
        bananaPrice.text = String(describing: bP)
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

